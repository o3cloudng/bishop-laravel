<?php
symlink('/home/bishopkunleamoo/laravel/storage/app/public', '/home/bishopkunleamoo/public_html/storage');

?>